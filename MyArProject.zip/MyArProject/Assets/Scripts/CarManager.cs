using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class CarManager : MonoBehaviour
{
    public GameObject indicator;
    public GameObject myCar;
    GameObject placedObject = null;
    public float rotSpeed = -0.1f;
    public float relocationDistance = 1.0f;

    ARRaycastManager arManager;
    List<ARRaycastHit> hitInfos = new List<ARRaycastHit>();   // Ray�� �ε��� ������ ������ ������ ����Ʈ

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        arManager = GetComponent<ARRaycastManager>();
        indicator.SetActive(false);    // Indicator ������Ʈ ��Ȱ��ȭ
    }

    // Update is called once per frame
    void Update()
    {
        DetectGround();    // �ٴ� ���� �� Indicator ��� �Լ�
    }

    void DetectGround()
    {
        Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);   // ��ũ�� �߾��� ��ġ

        if (arManager.Raycast(screenCenter, hitInfos, TrackableType.Planes))  // ��ũ�� �߾ӿ��� ���̸� �߻����� �� Plane Ÿ���� ���� ����� �ִ� ���
        {
            indicator.SetActive(true);   // Indicator ������Ʈ Ȱ��ȭ

            indicator.transform.position = hitInfos[0].pose.position;
            indicator.transform.rotation = hitInfos[0].pose.rotation;

            indicator.transform.position += indicator.transform.up * 0.01f;
        }
        else
        {
            indicator.SetActive(false);  // Plane Ÿ���� ���� ����� ���� ��� Indicator ������Ʈ ��Ȱ��ȭ
        }
    }

    public void OnTouch(InputAction.CallbackContext context) 
    {
        if (context.performed) 
        {
            if (EventSystem.current.currentSelectedGameObject) 
            {
                return;
            }
            if (indicator.activeInHierarchy) 
            {
                if (placedObject == null)
                {
                    placedObject = Instantiate(myCar, indicator.transform.position, indicator.transform.rotation);
                }
                else 
                {
                    if (Vector3.Distance(placedObject.transform.position, indicator.transform.position) > relocationDistance) 
                    {
                        placedObject.transform.SetPositionAndRotation(indicator.transform.position, indicator.transform.rotation);
                    }
                    
                }
            }
        }
    }

    public void OnSwipe(InputAction.CallbackContext context) 
    {
        if (context.performed) 
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hitInfo;
            if (Physics.Raycast(ray, out hitInfo, Mathf.Infinity, 1 << 8)) 
            {
                Vector2 deltaPos = context.ReadValue<Vector2>();
                placedObject.transform.Rotate(placedObject.transform.up, deltaPos.x * rotSpeed);
            }
        }
    }
}