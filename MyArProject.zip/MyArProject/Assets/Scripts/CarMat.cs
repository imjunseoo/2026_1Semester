using UnityEngine;

public class CarMat : MonoBehaviour
{
    public Material[] carMats;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ChangeColor(int num) 
    {
        transform.Find("Body").gameObject.GetComponent<MeshRenderer>().material = carMats[num];
    }
}
